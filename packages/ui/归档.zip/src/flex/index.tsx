import { forwardRef } from 'react';
import { toUnit, View, ViewProps } from '../view';
/**
 * Flex 組件：現在可以更簡潔，直接透傳給 Box
 */
export interface FlexProps extends ViewProps<'div'> {
    /** 布局方向: row(默认) | column | row-reverse | column-reverse */
    direction?: 'row' | 'row-reverse' | 'column' | 'column-reverse';
    /** 交叉轴对齐: center | flex-start | flex-end | stretch */
    align?: 'flex-start' | 'center' | 'flex-end' | 'stretch' | 'baseline';
    /** 主轴对齐方式 */
    justify?: 'flex-start' | 'center' | 'flex-end' | 'space-between' | 'space-around' | 'space-evenly';
    /** 间距 (数字单位为 px) */
    gap?: string | number;
    wrap?: 'nowrap' | 'wrap' | 'wrap-reverse';
    shrink?: number;
    flex?: string | number; // 快捷设置 flex: 1 1 auto 等
}

export const Flex = forwardRef<HTMLDivElement, FlexProps>(({
    direction, align, justify, gap, wrap, shrink, flex, style, ...rest
}, ref) => (
    <View
        ref={ref}
        style={{
            display: 'flex',
            flexDirection: direction,
            alignItems: align,
            justifyContent: justify,
            flexWrap: wrap,
            gap: toUnit(gap),
            flexShrink: shrink,
            flex,
            ...style,
        }}
        {...rest} // m, p, px, py 等屬性都在 rest 裡，會被 Box 處理
    />
));

/**
 * FlexItem 同理優化
 */
export const FlexItem = forwardRef<any, FlexProps>(({ flex, alignSelf, order, style, ...rest }, ref) => (
    <View
        ref={ref}
        style={{
            flex,
            alignSelf,
            order,
            ...style,
        }}
        {...rest}
    />
));

// 这一行非常关键，能显著提升 VS Code 的识别率
// Flex.displayName = 'Flex'; 
// FlexItem.displayName = 'FlexItem'; 