import React, { forwardRef, useState, useEffect } from 'react';
import { View } from '../view';
// import { Tooltip } from '../tooltip';
import { CLASSNAME } from '../config';
import './index.less';

const sizeMapping: any = { small: 24, medium: 32, large: 48 };
const radiusMapping: any = { none: 0, small: 2, medium: 4, large: 6, full: '50%' };

export const Avatar = forwardRef<HTMLDivElement, any>((props, ref) => {
    const { 
        status: propsStatus, 
        size = 'medium', 
        radius = 'medium', 
        icon, 
        children, 
        title, 
        onClick, 
        bg, 
        borderColor = '#fff', // 建議這裡預設顏色
        style, ...rest 
    } = props;
    const [localStatus, setLocalStatus] = useState(propsStatus);
    useEffect(() => { setLocalStatus(propsStatus); }, [propsStatus]);

    const finalSize = typeof size === 'number' ? size : sizeMapping[size];
    const borderRadius = typeof radius === 'number' ? radius : radiusMapping[radius];

    const cls = [
        `${CLASSNAME}-avatar`,
        // `${CLASSNAME}-avatar-${type}`,
        localStatus === 'offline' && `${CLASSNAME}-avatar-offline-mode`
    ].filter(Boolean).join(' ');

    const avatarNode = (
        <View
            ref={ref} 
            className={cls} 
            w={finalSize} 
            h={finalSize} 
            bg={bg}
            borderRadius={borderRadius} // 確保圓角生效
            position="relative" // 必須開啟 relative 以定位 status
            style={{ 
                // 2. 關鍵：用 box-shadow 代替 border，實現留白且不影響布局
                boxShadow: `0 0 0 2px ${borderColor}`, 
                ...style 
            }}
            onClick={(e: any) => onClick?.(e)} 
            {...rest}
        >
            <div className={`${CLASSNAME}-avatar-content`}>
                {typeof icon === 'string' ? <img src={icon} alt="" /> : icon}
                {children}
            </div>
            {localStatus && (
                <span 
                    className={`${CLASSNAME}-avatar-status ${CLASSNAME}-avatar-status-${localStatus}`} 
                    style={{
                        position: 'absolute',
                        bottom: 0, // 圓形時向中心偏移
                        right: 0,
                        transform: 'translate(50%, 50%)',
                        zIndex: 2,
                        border: `1.5px solid ${borderColor}` // 狀態點也要邊框
                    }}
                />
            )}
        </View>
    );

    return avatarNode;
});

export const AvatarGroup: React.FC<any> = ({ children, maxCount, size = 'medium', radius = 'medium', borderColor, status, ...rest }) => {
    const childrenArray = React.Children.toArray(children);
    const displayChildren = maxCount ? childrenArray.slice(0, maxCount) : childrenArray;
    const remainingCount = childrenArray.length - (maxCount || 0);

    return (
        <View className={`${CLASSNAME}-avatar-group`} flex align="center" {...rest}>
            {displayChildren.map((child: any, i) => {
                return React.cloneElement(child, {
                    key: i,
                    // 1. 確保 size 和 type 都能傳遞給子組件
                    size: child.props.size || size,
                    radius: child.props.radius || radius, 
                    status: status || child.props.status,
                    bg: child.props.bg, 
                    borderColor: child.props.borderColor || borderColor,
                    style: { ...child.props.style, marginLeft: i === 0 ? 0 : -8, transitionDelay: `${i * 0.05}s` }
                });
            })}
            {maxCount && childrenArray.length > maxCount && (
                // 2. 這裡也要傳遞 type，否則 "+N" 的那個塊也會是方的
                <Avatar size={size} radius={radius} className={`${CLASSNAME}-avatar-count`}>
                    +{remainingCount}
                </Avatar>
            )}
        </View>
    );
};