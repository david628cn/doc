import React, { ChangeEvent, ChangeEventHandler, ReactEventHandler, useEffect, useState } from 'react';
import { CLASSNAME } from '../config';
import './index.less';

export type InputProps = {
    className?: string;
    type?: string;
    value?: string;
    name?: string;
    defaultValue?: string;
    children?: React.ReactNode;
    onChange?: (params: any) => void;
    [key: string]: unknown;
}

export const Input: React.FC<InputProps> = props => {
    const {
        className,
        type,
        name,
        value,
        defaultValue,
        onChange,
        ...otherProps
    } = props;

    const [text, setText] = useState(value || defaultValue || '');

    useEffect(() => {
        if ('value' in props) {
            setText(value || '');
        }
    }, [value]);

    const handleChange = (event: any) => {
        const value = event.target.value;
        onChange?.({
            value,
            event
        });
    };

    const cls = [`${CLASSNAME}-input`];

    if (className) {
        cls.push(className);
    }

    if (type === 'textarea') {
        return <textarea
            className={cls.join(' ')}
            autoComplete="off"
            value={text}
            name={name}
            onChange={handleChange}
            {...otherProps}
        ></textarea>
    }

    return <input
        className={cls.join(' ')}
        autoComplete="off"
        type={type}
        value={text}
        name={name}
        onChange={handleChange}
        {...otherProps}
    />;
}