import React, { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react';

export type VirtualScrollProps<T extends Record<string, unknown>> = {
	items: T[];
	itemKey: keyof T & string;
	estimatedHeight?: number;
	buffer?: number;
	className?: string;
	style?: React.CSSProperties;
	children: (item: T, measureRef: (el: HTMLElement | null) => void) => React.ReactNode;
};

type LayoutRow = Record<string, unknown> & {
	_top: number;
	_height: number;
	_bottom: number;
};

/**
 * 虚拟滚动：仅挂载视口内 + buffer 行，总高度用占位撑开 scrollHeight。
 */
export function VirtualScroll<T extends Record<string, unknown>>({
	items,
	itemKey,
	estimatedHeight = 32,
	buffer = 6,
	className,
	style,
	children,
}: VirtualScrollProps<T>) {
	const [scrollTop, setScrollTop] = useState(0);
	const [viewportHeight, setViewportHeight] = useState(0);
	const [measurements, setMeasurements] = useState<Record<string, number>>({});
	const containerRef = useRef<HTMLDivElement>(null);
	const measureRefCache = useRef<Map<string, (el: HTMLElement | null) => void>>(new Map());

	const syncViewportFromEl = useCallback((el: HTMLDivElement | null) => {
		if (!el) return;
		const ch = el.clientHeight;
		if (ch > 0) {
			setViewportHeight(prev => (Math.abs(prev - ch) > 0.5 ? ch : prev));
		}
	}, []);

	const getMeasureRef = useCallback(
		(key: string) => {
			if (!measureRefCache.current.has(key)) {
				measureRefCache.current.set(key, (el: HTMLElement | null) => {
					if (!el) return;
					const h = el.getBoundingClientRect().height;
					if (h > 0 && Math.abs((measurements[key] || 0) - h) > 0.1) {
						requestAnimationFrame(() => {
							setMeasurements(prev => {
								if (prev[key] === h) return prev;
								return { ...prev, [key]: h };
							});
						});
					}
				});
			}
			return measureRefCache.current.get(key)!;
		},
		[measurements]
	);

	useEffect(() => {
		const el = containerRef.current;
		if (!el) return;
		const ro = new ResizeObserver(() => {
			syncViewportFromEl(containerRef.current);
		});
		ro.observe(el);
		syncViewportFromEl(el);
		return () => ro.disconnect();
	}, [syncViewportFromEl]);

	useLayoutEffect(() => {
		syncViewportFromEl(containerRef.current);
		const id = requestAnimationFrame(() => syncViewportFromEl(containerRef.current));
		return () => cancelAnimationFrame(id);
	}, [items.length, syncViewportFromEl]);

	const { layoutItems, totalHeight } = useMemo(() => {
		let currentTop = 0;
		const safeItems = items.filter((item): item is T => item != null);
		const layouts: LayoutRow[] = safeItems.map(item => {
			const key = String(item[itemKey]);
			const h = measurements[key] || estimatedHeight;
			const row: LayoutRow = {
				...item,
				_top: currentTop,
				_height: h,
				_bottom: currentTop + h,
			};
			currentTop += h;
			return row;
		});
		return { layoutItems: layouts, totalHeight: currentTop };
	}, [items, measurements, itemKey, estimatedHeight]);

	/** 第一个满足 _bottom > scrollTop 的行（与视口上沿相交的最早一行） */
	const startIndex = useMemo(() => {
		const n = layoutItems.length;
		if (n === 0) return 0;
		let low = 0;
		let high = n - 1;
		while (low <= high) {
			const mid = (low + high) >> 1;
			if (layoutItems[mid]._bottom > scrollTop) {
				if (mid === 0 || layoutItems[mid - 1]._bottom <= scrollTop) return mid;
				high = mid - 1;
			} else {
				low = mid + 1;
			}
		}
		return 0;
	}, [layoutItems, scrollTop]);

	/** 首个「行顶 >= scrollTop+clientHeight」的下标 lo；切片右端取 lo+buffer（含 overscan） */
	const endIndex = useMemo(() => {
		const n = layoutItems.length;
		if (n === 0) return 0;
		const targetTop = scrollTop + viewportHeight;
		if (targetTop <= 0) {
			return Math.min(n, Math.max(startIndex, 0) + buffer + 2);
		}
		let lo = 0;
		let hi = n;
		while (lo < hi) {
			const mid = (lo + hi) >> 1;
			if ((layoutItems[mid] as LayoutRow)._top >= targetTop) {
				hi = mid;
			} else {
				lo = mid + 1;
			}
		}
		return Math.min(n, lo + buffer);
	}, [layoutItems, scrollTop, viewportHeight, buffer, startIndex]);

	const { start, end, visibleData, offsetTop } = useMemo(() => {
		const n = layoutItems.length;
		const start = Math.max(0, startIndex - buffer);
		const end = Math.max(start + 1, Math.min(n, endIndex));
		const visibleData = layoutItems.slice(start, end);
		const offsetTop = layoutItems[start]?._top ?? 0;
		return { start, end, visibleData, offsetTop };
	}, [layoutItems, startIndex, endIndex, buffer]);

	const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
		const t = e.currentTarget;
		setScrollTop(t.scrollTop);
		syncViewportFromEl(t);
	};

	return (
		<div
			ref={containerRef}
			className={className}
			onScroll={handleScroll}
			style={{
				width: '100%',
				overflow: 'auto',
				overflowAnchor: 'none',
				position: 'relative',
				WebkitOverflowScrolling: 'touch',
				height: '100%',
				...style,
			}}
		>
			<div
				style={{
					height: totalHeight,
					width: '100%',
					position: 'relative',
					pointerEvents: 'none',
				}}
			>
				<div
					style={{
						position: 'absolute',
						top: offsetTop,
						left: 0,
						width: '100%',
						pointerEvents: 'auto',
					}}
				>
					{visibleData.map(item => {
						const k = String(item[itemKey]);
						return (
							<React.Fragment key={k}>
								{children(item as T, getMeasureRef(k))}
							</React.Fragment>
						);
					})}
				</div>
			</div>
		</div>
	);
}
