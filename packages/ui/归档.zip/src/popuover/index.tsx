import React, { useState, useEffect, useRef, useCallback } from 'react';
import ReactDOM from 'react-dom';
import { findParentWithPosition, getAlignPos, setPos, getRect } from '../utils/align';
import { CLASSNAME } from '../config';
import './index.less';

export type PopuoverProps = {
    className?: string;
    container?: any;
    defaultOpen?: boolean;
    open?: boolean;
    pos?: string;
    gap?: number;
    dxy?: number[];
    trigger?: string | Array<string>;
    translate?: boolean;
    items?: React.ReactNode;
    mask?: boolean;
    rect?: any;
    // targetRef?: any;
    children?: React.ReactNode;
    popuoverProps?: any;
    // mouseEnterDelay?: number;
    mouseLeaveDelay?: number;
    onChange?: Function;
    // onPopuoverMouseEnter?: Function;
    // onPopuoverMouseLeave?: Function;
    // onPopuoverMouseDown?: Function;
    [key: string]: unknown;
}

export const Popuover: React.FC<PopuoverProps> = props => {
    const {
        // onChange,
        items,
        pos = 'tl-bl?',
        rect,
        translate = false,
        gap = 0,
        dxy = [0, 0],
        children,
        // mouseEnterDelay = 0,
        mouseLeaveDelay = 0.1,
        // targetRef,
        container,
        popuoverProps,
        mask = false,
        trigger = 'click'
    } = props;

    const [open, setOpen] = useState(props.open || props.defaultOpen || false);
    const anchorRef: any = useRef(null);
    const popuoverRef: any = useRef(null);
    const innerRef: any = useRef(null);
    const openRef: any = useRef(props.open || props.defaultOpen || false);
    openRef.current = open;

    // const rectRef: any = useRef(rect);
    // rectRef.current = rect;
    // anchorRef.current = targetRef?.current;
    
    const delayerRef = useRef<any>({
        timer: null,
        clear() {
            if (this.timer) {
                clearTimeout(this.timer);
                this.timer = null;
            }
        },
        start(callback: Function, delay: number = 0) {
            this.clear();
            const self = this;
            this.timer = setTimeout(() => {
                self.clear();
                callback?.();
            }, delay * 1000) as any;
        }
    });

    const updatePosition = useCallback(() => {
        const el = container || document.body;
        let xy: any;
        if (!('rect' in props)) {
            if (openRef.current && anchorRef.current && popuoverRef.current) {
                // setTimeout(() => {
                xy = getAlignPos(popuoverRef.current, anchorRef.current, {
                    pos,
                    gap,
                    dxy,
                    container: el
                });
                // setPos(popuoverRef.current, xy, translate);
                // }, 1000);

            }
        } else {
            if (openRef.current && rect && popuoverRef.current) {
                // setTimeout(() => {
                xy = getAlignPos(popuoverRef.current, rect, {
                    pos,
                    gap,
                    dxy,
                    container: el
                });
                // setPos(popuoverRef.current, xy, translate);
                // }, 1000);

            }
        }
        if (xy) {
            let left = xy.left;
            let top = xy.top;
            // if (el) {
                const pdom = findParentWithPosition(el);
                if (pdom) {
                    const containerRect = getRect(pdom);
                    left -= containerRect.left;
                    top -= containerRect.top;
                }
            // }
            setPos(popuoverRef.current, { left, top }, translate);
        }
        if (popuoverRef.current) {
            if (openRef.current) {
                popuoverRef.current.classList.add(`${CLASSNAME}-popuover-open`);
                innerRef.current.classList.add('animated');
                innerRef.current.classList.add('slideDownIn');
            } else {
                innerRef.current.classList.remove('animated');
                innerRef.current.classList.remove('slideDownIn');
                popuoverRef.current.classList.remove(`${CLASSNAME}-popuover-open`);
            }
        }
        
    }, [openRef.current]);

    useEffect(() => {
        const handleDocClick = (e: any) => {
            if (!('rect' in props)) {
                if (!popuoverRef.current?.contains(e.target) && !anchorRef.current?.contains(e.target)) {
                    if (openRef.current !== false) {
                        // if (!('open' in props)) {
                        //     setOpen(false);
                        // }
                        // onChange?.(false, {
                        //     event: e
                        // });
                        setPopupVisible(false, 'docMousedown', e);
                    }
                }
            } else {
                if (!popuoverRef.current?.contains(e.target)) {
                    if (openRef.current !== false) {
                        // if (!('open' in props)) {
                        //     setOpen(false);
                        // }
                        // onChange?.(false, {
                        //     event: e
                        // });
                        setPopupVisible(false, 'docMousedown', e);
                    }
                    return;
                }
            }
        };
        document.addEventListener('mousedown', handleDocClick, false);
        document.addEventListener('touchstart', handleDocClick, { passive: false });
        return () => {
            document.removeEventListener('mousedown', handleDocClick);
            document.removeEventListener('touchstart', handleDocClick);
        }
    }, []);

    useEffect(() => {
        if (openRef.current) {
            updatePosition();
            const resizeObserver = new ResizeObserver(() => {
                // 在下一帧或绘制后同步位置
                updatePosition();
            });
            if (!('rect' in props)) {
                if (anchorRef.current) {
                    resizeObserver.observe(anchorRef.current);
                }
            }
            if (popuoverRef.current) {
                resizeObserver.observe(popuoverRef.current);
            }
            document.addEventListener('scroll', updatePosition, true);
            window.addEventListener('resize', updatePosition);

            return () => {
                resizeObserver.disconnect();
                document.removeEventListener('scroll', updatePosition, true);
                window.removeEventListener('resize', updatePosition);
            };
        }

    }, [openRef.current]);

    useEffect(() => {
        if ('open' in props) {
            setOpen(props.open || false);
        }
    }, [props.open]);

    const delaySetPopupVisible = (v: boolean, action: string, event?: any) => {
        delayerRef.current.start(() => {
            if (!('open' in props)) {
                setOpen(v);
            }
            props.onChange?.({
                open: v,
                event,
                action
            });
        }, mouseLeaveDelay);
    }

    const setPopupVisible = (v: boolean, action: string, event?: any) => {
        delayerRef.current.clear();
        if (!('open' in props)) {
            setOpen(v);
        }
        props.onChange?.({
            open: v,
            event,
            action
        });
    }

    const handleContextMenu = (e: any) => {
        // e.preventDefault();
        anchorRef.current = e.currentTarget as HTMLElement;
        setPopupVisible(!openRef.current, 'contextMenu', e);
    }

    const handleClick = (e: any) => {
        anchorRef.current = e.currentTarget as HTMLElement;
        if (trigger.includes('click')) {
            setPopupVisible(!openRef.current, 'click', e);
        }
    }

    const handleMouseDown = (e: any) => {
        if (trigger.includes('mouseDown')) {
            anchorRef.current = e.currentTarget as HTMLElement;
            setPopupVisible(!openRef.current, 'mouseDown', e);
        }
    }

    const handleMouseEnter = (e: any) => {
        anchorRef.current = e.currentTarget as HTMLElement;
        setPopupVisible(true, 'mouseEnter', e);
    }

    const handleMouseLeave = (e: any) => {
        anchorRef.current = e.currentTarget as HTMLElement;
        delaySetPopupVisible(false, 'mouseLeave', e);
    }

    const handleFocus = (e: any) => {
        anchorRef.current = e.currentTarget as HTMLElement;
        if (trigger.includes('focus')) {
            setPopupVisible(true, 'focus', e);
        } else if (trigger.includes('blur')) {
            delaySetPopupVisible(false, 'blur', e);
        }
    }

    const handleBlur = (e: any) => {
        anchorRef.current = e.currentTarget as HTMLElement;
        if (trigger.includes('blur')) {
            setPopupVisible(true, 'blur', e);
        } else if (trigger.includes('focus')) {
            delaySetPopupVisible(false, 'focus', e);
        }
    }

    const getChildrenProps = () => {
        const childProps: any = {};
        if (trigger.includes('contextMenu')) {
            childProps.onContextMenu = handleContextMenu;
        }
        if (trigger.includes('click')) {
            childProps.onClick = handleClick;
        }
        if (trigger.includes('mouseDown')) {
            childProps.onMouseDown = handleMouseDown;
            childProps.onTouchStart = handleMouseDown;
        }
        if (trigger.includes('hover')) {
            childProps.onMouseEnter = handleMouseEnter;
            childProps.onMouseLeave = handleMouseLeave;
        }

        if (trigger.includes('focus') || trigger.includes('blur')) {
            childProps.onFocus = handleFocus;
            childProps.onBlur = handleBlur;
        }
        return childProps;
    }

    const handlePopuoverContextMenu = (e: any) => {
        setPopupVisible(!openRef.current, 'contextMenu', e);
    }

    const handlePopuoverMouseEnter = (e: any) => {
        // e.preventDefault();
        setPopupVisible(true, 'popuoverMouseEnter', e);
    }

    const handlePopuoverMouseLeave = (e: any) => {
        e.preventDefault();
        delaySetPopupVisible(false, 'popuoverMouseLeave', e);
    }

    const getPopuoverProps = () => {
        const nextPopuoverProps: any = {
            ...popuoverProps
        };

        if (!('rect' in props)) {
            if (trigger.includes('contextMenu')) {
                nextPopuoverProps.onContextMenu = handlePopuoverContextMenu;
            }
        }

        if (trigger.includes('hover') || trigger.includes('mouseEnter')) {
            nextPopuoverProps.onMouseEnter = handlePopuoverMouseEnter;
        }
        if (trigger.includes('hover')) {
            nextPopuoverProps.onMouseLeave = handlePopuoverMouseLeave;
        }
        return nextPopuoverProps;
    }

    const renderContent = () => {
        if (!openRef.current) {
            return null;
        }

        const cls = [`${CLASSNAME}-popuover-container`];
        if (props.className) {
            cls.push(props.className);
        }

        let content;
        if ('rect' in props) {
            content = children;
        } else {
            content = items;
        }

        const inner = <div
                    {...getPopuoverProps()}
                    className={cls.join(' ')}
                    ref={popuoverRef}
                >
                    <div className={`${CLASSNAME}-popuover-inner`} ref={innerRef}>
                        {content}
                    </div>
                    
                </div>;
        
        if (mask) {
            return ReactDOM.createPortal(
                <div className={`${CLASSNAME}-popuover-mask`}>
                    {inner}
                </div>
                , container || document.body);
        }
        return ReactDOM.createPortal(inner, container || document.body);
    };

    const renderTarget = () => {
        if (!children || ('rect' in props)) {
            return null;
        }
        const targetNode = React.cloneElement(children as any, getChildrenProps());
        return targetNode;
        // return <div
        //     className={`${CLASSNAME}-popuover-target`}
        //     ref={anchorRef}
        //     {...getChildrenProps()}
        // >
        //     {children}
        // </div>;
    }

    return (
        <>
            {renderTarget()}
            {renderContent()}
        </>

    );
}