import React, { useState } from 'react';
import { CLASSNAME } from '../config';
import './index.less';

export type TabProps = {
    className?: string;
    defaultActiveKey?: string;
    activeKey?: string;
    items?: Array<any>;
    onTabChange?: (index: number) => void;
    // [key: string]: unknown
}

export const Tab: React.FC<TabProps> = props => {
    const [activeKey, setActiveKey] = useState(props.activeKey || props.defaultActiveKey || (props.items || [])[0]?.key);

    const handleClick = (key: number) => {
        return (e: any) => {
            e.preventDefault();
            if (!('activeKey' in props)) {
                setActiveKey(key);
            }
            props.onTabChange?.(key);
        }
    }

    const nav: any = [];
    const content: any = [];
    (props.items || []).forEach((item: any, index: number) => {
        nav.push(
            <div
                key={index}
                className={item.key && (item.key === activeKey) ? `${CLASSNAME}-tab-nav ${CLASSNAME}-tab-nav-active` : `${CLASSNAME}-tab-nav`}
                onClick={handleClick(item.key)}
            >
                <div className={`${CLASSNAME}-tab-nav-label`}>{item.label}</div>
            </div>
        );
        content.push(
            <div key={index} className={item.key && (item.key === activeKey) ? `${CLASSNAME}-tab-content ${CLASSNAME}-tab-content-active` : `${CLASSNAME}-tab-content`}>
                {item.children}
            </div>
        );
    })

    return (
        <div className={`${CLASSNAME}-tab-container`}>
            <div className={`${CLASSNAME}-tab-nav-container`}>
                { nav }
            </div>
            <div className={`${CLASSNAME}-tab-content-container`}>
                { content }
            </div>
        </div>
    );
}