import React from 'react';
import { Popuover } from '../popuover';
import { CLASSNAME } from '../config';
import './index.less';

export type TooltipProps = {
    className?: string;
    defaultOpen?: boolean;
    open?: boolean;
    gap?: number;
    trigger?: string | Array<string>;
    // hideTrigger?: string | Array<string>;
    title?: React.ReactNode;
    pos?: string;
    offset?: Array<number>;
    mouseEnterDelay?: number;
    mouseLeaveDelay?: number;
    onChange?: Function;
    children?: React.ReactNode;
    [key: string]: unknown;
}

export const Tooltip: React.FC<TooltipProps> = props => {
    const {
        gap = 10,
        pos = 'b-t?',
        trigger = 'hover',
        title,
        className,
        ...otherProps
    } = props;

    const cls = [`${CLASSNAME}-tooltip-container`];
    if (className) {
        cls.push(className);
    }
    return <Popuover
        {...otherProps}
        gap={gap}
        pos={pos}
        items={title}
        trigger={trigger}
        className={cls.join(' ')}
    />;
}